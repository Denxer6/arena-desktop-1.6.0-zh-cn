Arena Desktop 1.6.0 简体中文补丁

1. 完全退出 Arena Desktop。
2. 将 ZIP 中的所有文件解压到同一个文件夹，双击 Install.cmd。
3. 看到“安装成功”后，重新启动 Arena Desktop。

补丁默认查找 %LOCALAPPDATA%\Programs\Arena Desktop\Arena-Desktop.exe。
如果没有找到，脚本会提示输入程序文件的完整路径。也可以将 Arena-Desktop.exe 拖到 Install.cmd 上指定文件。

还原英文版
完全退出 Arena Desktop，双击 Restore.cmd。如果安装时指定了自定义路径，还原时也可将对应的 Arena-Desktop.exe 拖到 Restore.cmd 上。原版备份位于程序同目录，文件名为 Arena-Desktop.exe.zh-cn-original.bak。

适用范围
补丁仅支持原始压缩包中的 Windows 1.6.0 构建，安装前会核对文件的 SHA-256。升级可能覆盖汉化，请勿将此补丁用于其他版本。补丁覆盖本地应用界面，模型名称、模型回复及第三方服务返回的内容保持原文。
