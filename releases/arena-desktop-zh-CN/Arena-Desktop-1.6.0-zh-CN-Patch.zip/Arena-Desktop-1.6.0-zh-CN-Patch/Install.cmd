@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Arena-Patch.ps1" -Mode Install -Interactive %*
set "patch_exit=%ERRORLEVEL%"
if not defined ARENA_PATCH_NO_PAUSE pause
exit /b %patch_exit%
