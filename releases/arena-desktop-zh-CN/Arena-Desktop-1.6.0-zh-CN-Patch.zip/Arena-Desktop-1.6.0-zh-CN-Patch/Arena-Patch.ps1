﻿param(
    [ValidateSet('Install','Restore')][string]$Mode = 'Install',
    [string]$Application = (Join-Path $env:LOCALAPPDATA 'Programs\Arena Desktop\Arena-Desktop.exe'),
    [switch]$Interactive
)
$ErrorActionPreference = 'Stop'

function Copy-FileRange($Source, $Destination, [long]$Offset, [long]$Length) {
    $Source.Position = $Offset
    $buffer = New-Object byte[] (1024 * 1024)
    while ($Length -gt 0) {
        $count = $Source.Read($buffer, 0, [int][Math]::Min($Length, $buffer.Length))
        if ($count -eq 0) { throw 'The source file ended unexpectedly.' }
        $Destination.Write($buffer, 0, $count)
        $Length -= $count
    }
}

$exitCode = 0
$temp = $null
try {
    $meta = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'patch.json') | ConvertFrom-Json
    if ($Interactive -and !(Test-Path -LiteralPath $Application -PathType Leaf)) {
        $Application = (Read-Host '请输入 Arena-Desktop.exe 的完整路径').Trim().Trim('"')
    }
    $target = Get-Item -LiteralPath $Application
    if ($target.PSIsContainer -or $target.Name -ine 'Arena-Desktop.exe') { throw 'Select Arena-Desktop.exe.' }
    $path = $target.FullName
    $backup = "$path.zh-cn-original.bak"
    $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
    if ($Mode -eq 'Install' -and $hash -eq $meta.patched) {
        Write-Host '已安装简体中文补丁。'
    } elseif ($Mode -eq 'Restore' -and $hash -eq $meta.original) {
        Write-Host '当前已是原版。'
    } else {
        $expected = if ($Mode -eq 'Install') { $meta.original } else { $meta.patched }
        if ($hash -ne $expected) { throw 'This file does not match the supported Arena Desktop 1.6.0 build. No changes made.' }
        $hasBackup = Test-Path -LiteralPath $backup
        if ($hasBackup -and (Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash -ne $meta.original) {
            throw "Backup hash mismatch: $backup"
        }
        $temp = "$path.zh-cn-$([Guid]::NewGuid().ToString('N')).tmp"
        if ($Mode -eq 'Install') {
            $source = [IO.File]::OpenRead($path)
            try {
                $destination = [IO.File]::Open($temp, [IO.FileMode]::CreateNew)
                try {
                    Copy-FileRange $source $destination 0 $meta.prefix
                    $bytes = [IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'ui.bin'))
                    $destination.Write($bytes, 0, $bytes.Length)
                    Copy-FileRange $source $destination $meta.suffixStart $meta.suffixLength
                    $bytes = [IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'toc.bin'))
                    $destination.Write($bytes, 0, $bytes.Length)
                } finally { $destination.Dispose() }
            } finally { $source.Dispose() }
            if ((Get-FileHash -LiteralPath $temp -Algorithm SHA256).Hash -ne $meta.patched) { throw 'Patch verification failed.' }
        } else {
            if (!$hasBackup) { throw 'Original backup is missing. Restore Arena-Desktop.exe from your original ZIP.' }
            [IO.File]::Copy($backup, $temp, $false)
            if ((Get-FileHash -LiteralPath $temp -Algorithm SHA256).Hash -ne $meta.original) { throw 'Backup verification failed.' }
        }
        if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $expected) { throw 'The application changed during the operation. Try again.' }
        if ($Mode -eq 'Install' -and !$hasBackup) {
            [IO.File]::Replace($temp, $path, $backup)
        } else {
            [IO.File]::Replace($temp, $path, [NullString]::Value)
        }
        if ($Mode -eq 'Install') {
            Write-Host '安装成功。请重新启动 Arena Desktop。'
            Write-Host "原版备份：$backup"
        } else {
            Write-Host '已恢复原版。'
        }
    }
} catch {
    Write-Host ($_.Exception.Message) -ForegroundColor Red
    $exitCode = 1
} finally {
    if ($temp -and (Test-Path -LiteralPath $temp -PathType Leaf)) { [IO.File]::Delete($temp) }
}
exit $exitCode
