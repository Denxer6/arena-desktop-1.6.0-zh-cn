# Arena Desktop

[English](README.md) | 简体中文

Arena Desktop 是面向 [arena.ai](https://arena.ai) 的非官方 Windows 桌面客户端。它将 Battle、Direct、Side by Side、Search 和 Agent Mode 集中在一个窗口，并提供本机工作区、MCP 连接器、账户切换和聊天历史管理。

> **非官方项目**：本项目由社区独立开发，与 Arena AI Inc. 无隶属关系，也未获得其认可。请使用自己的 arena.ai 账户并遵守 Arena 的服务条款。应用不会替你完成验证码，也不会绕过人工验证。

## 下载

所有版本都发布在 [GitHub Releases](https://github.com/PlayzAe/arena.ai-desktop/releases/latest)。

| 平台 | 文件 | 说明 |
| --- | --- | --- |
| Windows 10 / 11 | `Arena-Desktop-Setup.exe` | 安装程序，提供开始菜单和可选桌面快捷方式，也支持一键更新。 |
| Windows 10 / 11 | `Arena-Desktop.exe` | 便携版单文件程序。 |

首次运行时，Windows SmartScreen 可能提示未知发布者。点击“更多信息”，确认来源后再选择“仍要运行”。程序尚未进行代码签名。Windows 11 通常已内置 Edge WebView2 Runtime；Windows 10 若缺少该组件，请先安装 WebView2 Runtime。

## 界面语言

应用界面提供 English 和简体中文。默认跟随 Windows 显示语言：中文系统显示简体中文，其他系统显示英语。也可以在 **设置 → 语言** 中切换到“简体中文”“English”或“跟随系统语言”。语言选择保存在当前应用配置中，导出设置时也会一并导出。

翻译范围包括主窗口、模式和任务类型菜单、账户与登录、权限、工作区、记忆、自动化、用量、网关、组件、连接器、安装器及系统托盘菜单。arena.ai 网页内容、模型名称、模型生成的回答、用户提示词、文件名、路径和代码不会被翻译或改写。

## 主要功能

- **多种 Arena 模式**：Battle、Direct、Side by Side 和原生 Arena Agent Mode。
- **多种任务类型**：文本、图像、网页搜索、代码、视频和自动选择，具体可用性由 Arena 账户和服务端决定。
- **本机工作区**：选择一个文件夹，让本地智能体读取文件、编辑文件并运行命令。权限模式可控制是否需要逐次确认。
- **项目同步**：Code Mode 的项目文件可以保存到本机工作区；支持预览、打开文件夹和在本机启动开发服务器。
- **MCP 与连接器**：配置本地 MCP STDIO 服务器，并连接 Arena 提供的官方云端连接器。
- **多账户与历史记录**：保存多个登录账户，在本地聊天与 Arena 历史之间切换。
- **Agent Gateway**：可选的临时 Cloudflare 隧道，让 Arena Agent 连接本地 MCP 服务和指定工作区。
- **记忆和自动化**：在新对话中复用记忆，并按计划启动本地智能体任务。

## 工作区与权限

本地智能体只能在你选择的工作区中操作，并受设置中的权限模式控制：

- **询问后执行**：执行文件修改或命令前征求同意。
- **自动接受文件修改**：自动应用文件修改，命令仍需确认。
- **自动**：自动执行安全操作。
- **仅规划**：只读并生成计划，不修改文件。
- **跳过权限确认**：操作无需确认。此模式存在风险，请只在隔离环境中使用。

本机文件会保留在本机。卸载程序默认会保留项目文件夹；即使选择删除聊天、设置和已保存登录信息，也不会删除你的项目目录。

## Arena 限额与人工验证

Arena 的每日额度、速率限制和新账户功能限制仍然适用。应用会显示 Arena 返回的用量与重置时间，但不会绕过、隐藏或重置这些限制。失败的生成是否计入使用量由 Arena 服务决定。

若 Arena 要求验证码或人工验证，请在 Arena 窗口中自行完成。应用只会暂停当前操作并显示提示，不会自动识别或代做验证码。

## 从源码运行

需要 Python 3.11 或更高版本、Windows 和 WebView2 Runtime。双击 `START_ARENA_DESKTOP.bat` 可以创建虚拟环境、安装依赖并启动应用。

也可以在 Windows 命令行中手动运行：

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m arena.desktop
```

构建前端 JavaScript bundle：

```powershell
python scripts/build-js.py
```

运行测试：

```powershell
.\.venv\Scripts\python.exe -m pytest tests --ignore=tests/test_ui_browser.py
```

可选的浏览器测试需要安装 Playwright 和 Chromium：

```powershell
.\.venv\Scripts\python.exe -m pip install playwright
.\.venv\Scripts\python.exe -m playwright install chromium
$env:RUN_BROWSER_TESTS=1
.\.venv\Scripts\python.exe -m pytest tests/test_ui_browser.py
```

构建 Windows 发布文件：

```powershell
python scripts/build.py
```

## 常见问题

- **无法登录**：检查网络，然后在独立 Arena 窗口中登录；如出现人工验证，请手动完成。
- **429 或每日限额提示**：这是 Arena 的限额，不是客户端故障。请等待 Arena 显示的重置时间。
- **没有模型列表**：检查登录状态和 Arena 服务状态；部分模式会由 Arena 自动选择模型。
- **本地 Agent 无法运行命令**：检查工作区路径、权限模式，并确认 Node.js 或 Python 等所需组件已安装。
- **卸载应用**：在 Windows“设置 → 应用”中卸载，或运行安装目录中的 `Uninstall Arena Desktop.exe`。卸载不会删除项目文件夹。
- **日志位置**：`%USERPROFILE%\.arena-personal\desktop.log`。

## 当前限制

- 目前仅支持 Windows；macOS 和 Linux 尚未支持。
- Code Mode 使用 Arena 的云端沙盒；本机文件同步取决于工作区同步设置。
- 应用未进行代码签名，首次启动时 SmartScreen 可能发出提示。
- Arena 的服务条款、账户限制和人工验证要求始终优先适用。

## 安全与隐私

Arena Desktop 是本机运行的界面和工具集成，不承诺改变 Arena 的服务端处理方式。登录信息保存在本机配置中。不要将 Cookie、账户文件或包含密钥的 `mcp.json` 分享给他人。添加 MCP 服务器前，请先确认其来源和命令内容。

查看 [安全审计说明](SECURITY_AUDIT.md)、[已知问题](KNOWN_ISSUES.md) 和 [MIT License](LICENSE)。

## 参与翻译

简体中文界面会随系统语言自动选择，也可以在设置中手动切换。若发现翻译遗漏或表达不准确，欢迎通过 [GitHub Issues](https://github.com/PlayzAe/arena.ai-desktop/issues) 反馈，或提交 Pull Request。

## 致谢

由 [PlayzAe](https://github.com/PlayzAe) 与贡献者开发。主要贡献者包括 [Maxusimlive](https://github.com/Maxusimlive)。项目以 MIT License 发布。