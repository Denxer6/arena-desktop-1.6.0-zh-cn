"""Arena Desktop mini installer (per-user, no admin rights).

Installs Arena-Desktop.exe to %LOCALAPPDATA%\\Programs\\Arena Desktop, creates
Desktop and Start Menu shortcuts, and registers an uninstall entry in
Settings > Apps. Run again to repair or update. The same exe uninstalls:
Arena-Desktop-Setup.exe /uninstall asks whether to delete your data too (silent: /uninstall /S [/purge]).
Use /S for a silent install.
Your project folders are never touched.
"""
from __future__ import annotations

import json
import locale
import os
import time
import shutil
import subprocess
import sys
import threading
import winreg
from pathlib import Path

APP_NAME = "Arena Desktop"
EXE_NAME = "Arena-Desktop.exe"
SETUP_NAME = "Arena-Desktop-Setup.exe"
UNINSTALL_NAME = "Uninstall Arena Desktop.exe"
UNINSTALLER_BUNDLE = "Uninstall-Arena-Desktop.exe"
UNINSTALL_KEY = os.environ.get("ARENA_SETUP_REGKEY") or r"Software\Microsoft\Windows\CurrentVersion\Uninstall\ArenaDesktop"  # the override is for tests only
INSTALL_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))) / "Programs" / APP_NAME
START_MENU = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs"
NO_WINDOW = 0x08000000


def _is_chinese() -> bool:
    if os.name == "nt":
        try:
            import ctypes
            if ctypes.windll.kernel32.GetUserDefaultUILanguage() & 0x3FF == 0x04:
                return True
        except Exception:
            pass
    try:
        if str(locale.getlocale()[0] or "").lower().startswith("zh"):
            return True
    except Exception:
        pass
    return any(str(os.environ.get(key, "")).lower().startswith("zh")
               for key in ("LC_ALL", "LC_MESSAGES", "LANG"))


def _tr(english: str, chinese: str) -> str:
    return chinese if _is_chinese() else english


def bundle(name: str) -> Path:
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent)) / name


def app_version() -> str:
    try:
        return bundle("version.txt").read_text(encoding="utf-8").strip()
    except OSError:
        return "0"


def desktop_dir() -> Path:
    if os.environ.get("ARENA_SETUP_NO_KILL"):  # test mode: never touch the real Desktop
        return Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Desktop"
    r = subprocess.run(["powershell", "-NoProfile", "-Command", "[Environment]::GetFolderPath('Desktop')"],
                       capture_output=True, text=True, creationflags=NO_WINDOW)
    out = r.stdout.strip()
    return Path(out) if out else Path.home() / "Desktop"


def make_shortcut(link: Path, target: Path) -> None:
    link.parent.mkdir(parents=True, exist_ok=True)
    q = lambda p: str(p).replace("'", "''")  # noqa: E731
    ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%s');"
          "$s.TargetPath='%s';$s.WorkingDirectory='%s';$s.IconLocation='%s,0';"
          "$s.Description='%s';$s.Save()") % (q(link), q(target), q(target.parent), q(target), APP_NAME)
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=True, creationflags=NO_WINDOW)


def stop_running_app() -> None:
    if os.environ.get("ARENA_SETUP_NO_KILL"):
        return
    subprocess.run(["taskkill", "/F", "/IM", EXE_NAME], capture_output=True, creationflags=NO_WINDOW)


def installed_version() -> str:
    """Version Windows has on record for the installed app, else the one next to the exe; '' when not installed."""
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY) as k:
            if (INSTALL_DIR / EXE_NAME).is_file():
                return str(winreg.QueryValueEx(k, "DisplayVersion")[0])
    except OSError:
        pass
    try:
        return (INSTALL_DIR / "version.txt").read_text(encoding="utf-8").strip() if (INSTALL_DIR / EXE_NAME).is_file() else ""
    except OSError:
        return ""


def _vt(v: str) -> tuple:
    out = []
    for bit in str(v or "").lstrip("v").split("."):
        digits = "".join(c for c in bit if c.isdigit())
        out.append(int(digits) if digits else 0)
    return tuple(out) or (0,)


def place_uninstaller() -> None:
    """Put `Uninstall Arena Desktop.exe` in the program folder (Setup itself is not copied there)."""
    src = bundle(UNINSTALLER_BUNDLE)
    if not src.is_file() and getattr(sys, "frozen", False):
        src = Path(sys.executable)  # a Setup built without the uninstaller can still remove the app
    if src.is_file():
        tmp = (INSTALL_DIR / UNINSTALL_NAME).with_suffix(".new")
        shutil.copyfile(src, tmp)
        os.replace(tmp, INSTALL_DIR / UNINSTALL_NAME)
    (INSTALL_DIR / SETUP_NAME).unlink(missing_ok=True)  # older builds left Setup here


def register_uninstall(version: str) -> None:
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY) as k:
        for name, val in {
            "DisplayName": APP_NAME, "DisplayVersion": version, "Publisher": "Arena Desktop",
            "InstallLocation": str(INSTALL_DIR), "DisplayIcon": str(INSTALL_DIR / EXE_NAME),
            "UninstallString": f'"{INSTALL_DIR / UNINSTALL_NAME}"',
            "QuietUninstallString": f'"{INSTALL_DIR / UNINSTALL_NAME}" /S',
        }.items():
            winreg.SetValueEx(k, name, 0, winreg.REG_SZ, val)
        winreg.SetValueEx(k, "NoModify", 0, winreg.REG_DWORD, 1)
        winreg.SetValueEx(k, "NoRepair", 0, winreg.REG_DWORD, 1)


def install(desktop_shortcut: bool, progress=lambda pct, msg: None) -> Path:
    payload = bundle(EXE_NAME)
    if not payload.is_file():
        raise RuntimeError(_tr("Installer payload is missing. Re-download Arena-Desktop-Setup.exe.", "安装程序文件缺失，请重新下载 Arena-Desktop-Setup.exe。"))
    version = app_version()
    progress(10, _tr("Closing Arena Desktop if it is running", "正在关闭运行中的 Arena Desktop"))
    stop_running_app()
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    progress(30, _tr("Copying files", "正在复制文件"))
    target = INSTALL_DIR / EXE_NAME
    tmp = target.with_suffix(".new")
    shutil.copyfile(payload, tmp)
    os.replace(tmp, target)
    place_uninstaller()
    (INSTALL_DIR / "version.txt").write_text(version, encoding="utf-8")
    progress(65, _tr("Creating shortcuts", "正在创建快捷方式"))
    make_shortcut(START_MENU / f"{APP_NAME}.lnk", target)
    if desktop_shortcut:
        make_shortcut(desktop_dir() / f"{APP_NAME}.lnk", target)
    progress(90, _tr("Registering with Windows", "正在向 Windows 注册应用"))
    register_uninstall(version)
    progress(100, _tr("Done", "完成"))
    return target


def user_data_dirs() -> list:
    home = Path.home()
    return [home / ".arena-personal", home / ".arena-cli"]


def purge_user_data() -> None:
    """Chats, settings, saved sign-ins, web profile and update downloads. Project folders are never touched."""
    for d in user_data_dirs():
        shutil.rmtree(d, ignore_errors=True)


def schedule_remove_install_dir() -> None:
    # This exe lives in INSTALL_DIR, so a detached helper removes the folder after we exit.
    subprocess.Popen(f'cmd /c ping -n 3 127.0.0.1 >nul & cd /d "%TEMP%" & rmdir /s /q "{INSTALL_DIR}"',
                     cwd=os.environ.get("TEMP"), creationflags=NO_WINDOW | 0x00000008, close_fds=True)


def uninstall(purge: bool = False) -> None:
    stop_running_app()
    for link in (START_MENU / f"{APP_NAME}.lnk", desktop_dir() / f"{APP_NAME}.lnk"):
        link.unlink(missing_ok=True)
    try:
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY)
    except OSError:
        pass
    if purge:
        purge_user_data()
    # This exe lives in INSTALL_DIR, so a detached helper removes the folder after we exit.
    subprocess.Popen(f'cmd /c ping -n 4 127.0.0.1 >nul & cd /d "%TEMP%" & rmdir /s /q "{INSTALL_DIR}"',
                     cwd=os.environ.get("TEMP"), creationflags=NO_WINDOW | 0x00000008, close_fds=True)


def run_uninstall_gui_tk() -> None:
    import ctypes
    import tkinter as tk

    BG, FG, MUTED, LINE, DANGER, ON_DANGER = "#1b1e1e", "#f4f0eb", "#8b958e", "#2a2f2f", "#f87171", "#2b0a0a"
    root = tk.Tk()
    root.title(_tr(f"Uninstall {APP_NAME}", f"卸载 {APP_NAME}"))
    root.configure(bg=BG)
    root.resizable(False, False)
    root.geometry(f"440x250+{(root.winfo_screenwidth() - 440) // 2}+{(root.winfo_screenheight() - 250) // 3}")
    try:
        root.iconbitmap(default=str(bundle("arena-cli.ico")))
        root.update()
        ctypes.windll.dwmapi.DwmSetWindowAttribute(ctypes.windll.user32.GetParent(root.winfo_id()), 20, ctypes.byref(ctypes.c_int(1)), 4)
    except Exception:
        pass
    body = tk.Frame(root, bg=BG)
    body.pack(fill="both", expand=True, padx=28, pady=(24, 20))
    tk.Label(body, text=_tr(f"Remove {APP_NAME}?", f"要移除 {APP_NAME} 吗？"), bg=BG, fg=FG, font=("Segoe UI", 15, "bold")).pack(anchor="w")
    tk.Label(body, text=_tr("The app, its shortcuts and its entry in Settings > Apps will be removed.\nYour project folders are not touched.", "应用、快捷方式以及“设置 > 应用”中的条目都会被移除。\n你的项目文件夹不会受到影响。"),
             bg=BG, fg=MUTED, font=("Segoe UI", 9), justify="left").pack(anchor="w", pady=(6, 12))
    wipe = tk.BooleanVar(value=True)
    tk.Checkbutton(body, text=_tr("Also delete my chats, settings and saved sign-ins", "同时删除我的对话、设置和已保存的登录信息"), variable=wipe, bg=BG, fg=FG, selectcolor=BG,
                   activebackground=BG, activeforeground=FG, font=("Segoe UI", 10), bd=0, highlightthickness=0).pack(anchor="w")
    tk.Label(body, text=r"%USERPROFILE%\.arena-personal", bg=BG, fg=MUTED, font=("Consolas", 9)).pack(anchor="w", padx=24)
    foot = tk.Frame(body, bg=BG)
    foot.pack(side="bottom", fill="x")
    result = {"go": False}

    def go() -> None:
        result["go"] = True
        root.destroy()

    def flat(text, bg, fg, hot, cmd):
        b = tk.Button(foot, text=text, command=cmd, bg=bg, fg=fg, activebackground=hot, activeforeground=fg, relief="flat", bd=0,
                      padx=20, pady=6, cursor="hand2", font=("Segoe UI", 10, "bold" if bg != BG else "normal"),
                      highlightthickness=2, highlightbackground=BG, highlightcolor=FG)
        b.bind("<Enter>", lambda _e: b.configure(bg=hot))
        b.bind("<Leave>", lambda _e: b.configure(bg=bg))
        return b

    ok = flat(_tr("Uninstall", "卸载"), DANGER, ON_DANGER, "#fca5a5", go)
    ok.pack(side="right")
    flat(_tr("Cancel", "取消"), BG, MUTED, LINE, root.destroy).pack(side="right", padx=(0, 8))
    ok.focus_set()
    root.bind("<Escape>", lambda _e: root.destroy())
    root.mainloop()
    if result["go"]:
        uninstall(purge=wipe.get())


def run_gui_tk() -> None:
    import ctypes
    import tkinter as tk

    BG, FG, MUTED, LINE, ACCENT, ACCENT_HOT, ON_ACCENT, ERR = (
        "#1b1e1e", "#f4f0eb", "#8b958e", "#2a2f2f", "#34d399", "#4ee0ab", "#06251a", "#f87171")
    W, H = 480, 330
    SANS = "Segoe UI"
    existing = (INSTALL_DIR / EXE_NAME).is_file()

    root = tk.Tk()
    root.title(_tr(f"{APP_NAME} Setup", f"{APP_NAME} 安装程序"))
    root.configure(bg=BG)
    root.resizable(False, False)
    root.geometry(f"{W}x{H}+{(root.winfo_screenwidth() - W) // 2}+{(root.winfo_screenheight() - H) // 3}")
    try:
        root.iconbitmap(default=str(bundle("arena-cli.ico")))
    except tk.TclError:
        pass
    try:
        root.update()
        hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
        ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 20, ctypes.byref(ctypes.c_int(1)), 4)
    except Exception:
        pass

    body = tk.Frame(root, bg=BG)
    body.pack(fill="both", expand=True, padx=28, pady=(26, 22))

    head = tk.Frame(body, bg=BG)
    head.pack(fill="x")
    logo = tk.Canvas(head, width=44, height=44, bg=BG, highlightthickness=0)
    logo.pack(side="left")
    k = 44 / 512
    pts = lambda *xy: [c for x, y in zip(xy[::2], xy[1::2]) for c in ((256 + x) * k, (256 + y) * k)]  # noqa: E731
    r = 9
    logo.create_polygon(r, 0, 44 - r, 0, 44, 0, 44, r, 44, 44 - r, 44, 44, 44 - r, 44, r, 44, 0, 44, 0, 44 - r, 0, r, 0, 0,
                        smooth=True, fill="#252523", outline="")
    for line in ((-120, -100, 120, -100), (-90, -100, -90, 100), (0, -100, 0, 100), (90, -100, 90, 100),
                 (-120, 100, 120, 100), (-120, -100, 0, -160, 120, -100)):
        logo.create_line(*pts(*line), fill="#F4F0EB", width=2, capstyle="round", joinstyle="round")
    titles = tk.Frame(head, bg=BG)
    titles.pack(side="left", padx=14)
    tk.Label(titles, text=APP_NAME, bg=BG, fg=FG, font=(SANS, 15, "bold"), anchor="w").pack(anchor="w")
    tk.Label(titles, text=_tr(f"Version {app_version()}" + ("  ·  update" if existing else ""), f"版本 {app_version()}" + ("  ·  更新" if existing else "")),
             bg=BG, fg=MUTED, font=(SANS, 9), anchor="w").pack(anchor="w")

    tk.Frame(body, bg=LINE, height=1).pack(fill="x", pady=18)

    tk.Label(body, text=_tr("Install location", "安装位置"), bg=BG, fg=MUTED, font=(SANS, 9)).pack(anchor="w")
    tk.Label(body, text=r"%LOCALAPPDATA%\Programs\Arena Desktop", bg=BG, fg=FG,
             font=("Consolas", 10)).pack(anchor="w", pady=(2, 0))
    tk.Label(body, text=_tr("Just for your account. No administrator rights needed.", "仅为当前账户安装，无需管理员权限。"), bg=BG, fg=MUTED,
             font=(SANS, 9)).pack(anchor="w", pady=(2, 12))

    desk, launch = tk.BooleanVar(value=True), tk.BooleanVar(value=True)
    for text, var in ((_tr("Add a desktop shortcut", "创建桌面快捷方式"), desk), (_tr("Open Arena Desktop when done", "安装完成后打开 Arena Desktop"), launch)):
        tk.Checkbutton(body, text=text, variable=var, bg=BG, fg=FG, selectcolor=BG, activebackground=BG,
                       activeforeground=FG, font=(SANS, 10), bd=0, highlightthickness=0,
                       anchor="w").pack(anchor="w", pady=1)

    status = tk.Label(body, text=" ", bg=BG, fg=MUTED, font=(SANS, 9), anchor="w")
    status.pack(fill="x", pady=(14, 4))
    track = tk.Canvas(body, height=4, bg=LINE, highlightthickness=0)
    track.pack(fill="x")
    fill = track.create_rectangle(0, 0, 0, 4, fill=ACCENT, width=0)

    foot = tk.Frame(body, bg=BG)
    foot.pack(side="bottom", fill="x")

    def flat(text, bg, fg, hot, cmd, bold=False):
        b = tk.Button(foot, text=text, command=cmd, bg=bg, fg=fg, activebackground=hot, activeforeground=fg,
                      relief="flat", bd=0, padx=20, pady=6, cursor="hand2", font=(SANS, 10, "bold" if bold else "normal"),
                      highlightthickness=2, highlightbackground=BG, highlightcolor=ACCENT)
        b.bind("<Enter>", lambda _e: b.configure(bg=hot))
        b.bind("<Leave>", lambda _e: b.configure(bg=bg))
        return b

    action = flat(_tr("Update" if existing else "Install", "更新" if existing else "安装"), ACCENT, ON_ACCENT, ACCENT_HOT, lambda: go(), bold=True)
    action.pack(side="right")
    cancel = flat(_tr("Cancel", "取消"), BG, MUTED, LINE, root.destroy)
    cancel.pack(side="right", padx=(0, 8))
    action.focus_set()

    def progress(pct: int, msg: str) -> None:
        def draw() -> None:
            track.coords(fill, 0, 0, track.winfo_width() * pct / 100, 4)
            status.configure(text=msg, fg=MUTED)
        root.after(0, draw)

    def finish(target: Path) -> None:
        if launch.get():
            subprocess.Popen([str(target)], cwd=str(target.parent), creationflags=0x00000008, close_fds=True)
            root.after(700, root.destroy)
        else:
            status.configure(text=_tr("Installed.", "安装完成。"), fg=ACCENT)
            action.configure(text=_tr("Close", "关闭"), state="normal", command=root.destroy)
            cancel.pack_forget()

    def work() -> None:
        try:
            target = install(desk.get(), progress)
        except Exception as e:  # noqa: BLE001 - shown to the user
            msg = f"{_tr('Could not install', '无法安装')}: {e}"[:90]
            root.after(0, lambda: (status.configure(text=msg, fg=ERR), action.configure(text=_tr("Retry", "重试"), state="normal"),
                                   cancel.configure(state="normal")))
            return
        root.after(0, lambda: finish(target))

    def go() -> None:
        action.configure(state="disabled")
        cancel.configure(state="disabled")
        threading.Thread(target=work, daemon=True).start()

    root.bind("<Return>", lambda _e: action.invoke())
    root.bind("<Escape>", lambda _e: root.destroy())
    root.mainloop()



# ---------------------------------------------------------------------------
# HTML window (WebView2, the same engine the app uses): step list with live status
# ---------------------------------------------------------------------------
class _Api:
    def __init__(self, mode: str):
        self._mode = mode
        self._window = None
        self._target = INSTALL_DIR / EXE_NAME

    def _js(self, code: str) -> None:
        try:
            self._window.evaluate_js(code)
        except Exception:
            pass

    def _emit(self, i: int, status: str, info: str = "") -> None:
        self._js(f"onStep({i},{json.dumps(status)},{json.dumps(info)})")

    def get_state(self) -> dict:
        version = app_version()
        if self._mode == "install":
            steps = [
                {"icon": "close", "title": _tr("Close running app", "关闭正在运行的应用"), "sub": _tr("Stops Arena Desktop if it is open", "如果 Arena Desktop 正在运行则将其关闭")},
                {"icon": "copy", "title": _tr("Copy app files", "复制应用文件"), "sub": _tr("For your account only, no admin rights", "仅为当前账户安装，无需管理员权限")},
                {"icon": "link", "title": _tr("Create shortcuts", "创建快捷方式"), "sub": _tr("Start Menu, and Desktop if you want it", "开始菜单；也可选择创建桌面快捷方式")},
                {"icon": "trash", "title": _tr("Add the uninstaller", "添加卸载程序"), "sub": _tr(UNINSTALL_NAME + " in the program folder", UNINSTALL_NAME + " 将放在程序文件夹中")},
                {"icon": "shield", "title": _tr("Register with Windows", "注册到 Windows"), "sub": _tr(f"Adds it to Settings > Apps as {version}", f"以版本 {version} 添加到“设置 > 应用”")},
            ]
            options = [{"key": "desktop", "label": _tr("Add a desktop shortcut", "创建桌面快捷方式"), "on": True},
                       {"key": "launch", "label": _tr("Open Arena Desktop when done", "完成后打开 Arena Desktop"), "on": True}]
        else:
            steps = [
                {"icon": "close", "title": _tr("Close running app", "关闭正在运行的应用"), "sub": _tr("Stops Arena Desktop if it is open", "如果 Arena Desktop 正在运行则将其关闭")},
                {"icon": "link", "title": _tr("Remove shortcuts", "移除快捷方式"), "sub": _tr("Start Menu and Desktop", "开始菜单和桌面")},
                {"icon": "shield", "title": _tr("Remove Windows entry", "移除 Windows 条目"), "sub": _tr("Settings > Apps", "设置 > 应用")},
                {"icon": "trash", "title": _tr("Delete app files", "删除应用文件"), "sub": _tr("The program folder", "程序文件夹")},
                {"icon": "user", "title": _tr("Delete my data", "删除我的数据"), "sub": _tr("Chats, settings and saved sign-ins", "对话、设置和已保存的登录信息")},
            ]
            options = [{"key": "purge", "label": _tr("Also delete my chats, settings and saved sign-ins", "同时删除我的对话、设置和已保存的登录信息"), "on": True}]
        shown = str(INSTALL_DIR).replace(str(Path.home()), "~")
        have = installed_version()
        subtitle, button, notice = _tr(f"Version {version}", f"版本 {version}"), _tr("Install", "安装"), ""
        if self._mode == "uninstall":
            subtitle, button = _tr("Your project folders are never touched.", "你的项目文件夹不会受到影响。"), _tr("Uninstall", "卸载")
        elif have and _vt(have) == _vt(version):
            subtitle = _tr(f"Version {version} &middot; <b>up to date</b>", f"版本 {version} &middot; <b>已是最新版本</b>")
            button, notice = _tr("Repair", "修复"), _tr(f"You already have the latest version ({version}). Repair reinstalls the files and shortcuts.", f"当前已是最新版本（{version}）。修复会重新安装应用文件并创建快捷方式。")
        elif have and _vt(have) < _vt(version):
            subtitle, button = _tr(f"Version {version} &middot; <b>update from {have}</b>", f"版本 {version} &middot; <b>从 {have} 更新</b>"), _tr("Update", "更新")
        elif have:
            subtitle, button = _tr(f"Version {version}", f"版本 {version}"), _tr("Install anyway", "仍然安装")
            notice = _tr(f"A newer version ({have}) is already installed.", f"已安装较新版本（{have}）。")
        return {"mode": self._mode, "version": version, "existing": bool(have), "installed": have,
                "up_to_date": bool(have) and _vt(have) == _vt(version), "subtitle": subtitle, "button": button,
                "notice": notice, "path": shown, "steps": steps, "options": options,
                "locale": "zh-CN" if _is_chinese() else "en-US"}

    def start(self, opts: dict) -> bool:
        threading.Thread(target=self._run, args=(opts or {},), daemon=True).start()
        return True

    def _step(self, i: int, label_ok: str, fn) -> None:
        self._emit(i, "run")
        fn()
        time.sleep(0.25)
        self._emit(i, "ok", label_ok)

    def _run(self, opts: dict) -> None:
        current = 0
        try:
            if self._mode == "install":
                payload = bundle(EXE_NAME)
                if not payload.is_file():
                    raise RuntimeError(_tr("Installer payload is missing. Download Arena-Desktop-Setup.exe again.", "安装程序文件缺失，请重新下载 Arena-Desktop-Setup.exe。"))
                version = app_version()

                def copy() -> None:
                    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
                    tmp = self._target.with_suffix(".new")
                    shutil.copyfile(payload, tmp)
                    os.replace(tmp, self._target)
                    (INSTALL_DIR / "version.txt").write_text(version, encoding="utf-8")

                def shortcuts() -> None:
                    make_shortcut(START_MENU / f"{APP_NAME}.lnk", self._target)
                    if opts.get("desktop"):
                        make_shortcut(desktop_dir() / f"{APP_NAME}.lnk", self._target)

                self._step(0, _tr("Closed", "已关闭"), stop_running_app)
                current = 1
                self._step(1, _tr("Installed", "已安装"), copy)
                current = 2
                self._step(2, _tr("Shortcuts ready", "快捷方式已创建"), shortcuts)
                current = 3
                self._step(3, _tr("Uninstaller added", "卸载程序已添加"), place_uninstaller)
                current = 4
                self._step(4, _tr(f"Registered as {version}", f"已注册，版本 {version}"), lambda: register_uninstall(version))
                self._js(f"onDone(true,{json.dumps(_tr('Installed. Arena Desktop ' + version + ' is ready.', 'Arena Desktop ' + version + ' 已安装就绪。'))})")
            else:
                purge = bool(opts.get("purge"))

                def links() -> None:
                    for link in (START_MENU / f"{APP_NAME}.lnk", desktop_dir() / f"{APP_NAME}.lnk"):
                        link.unlink(missing_ok=True)

                def registry() -> None:
                    try:
                        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY)
                    except OSError:
                        pass

                self._step(0, _tr("Closed", "已关闭"), stop_running_app)
                current = 1
                self._step(1, _tr("Removed", "已移除"), links)
                current = 2
                self._step(2, _tr("Removed", "已移除"), registry)
                current = 3
                self._step(3, _tr("Removed when you close this window", "关闭此窗口后移除"), lambda: None)
                current = 4
                if purge:
                    self._step(4, _tr("Deleted", "已删除"), purge_user_data)
                else:
                    self._emit(4, "skip", _tr("Kept, as you chose", "按你的选择保留"))
                self._js(f"onDone(true,{json.dumps(_tr('Arena Desktop was removed.', 'Arena Desktop 已卸载。'))})")
        except Exception as e:  # noqa: BLE001 - shown in the step's drawer
            self._emit(current, "fail", str(e))
            self._js(f"onDone(false,{json.dumps(_tr('Stopped: ' + str(e)[:120], '已停止：' + str(e)[:120]))})")

    def finish(self, launch: bool = False) -> None:
        if self._mode == "install" and launch and (self._target).is_file():
            subprocess.Popen([str(self._target)], cwd=str(self._target.parent), creationflags=0x00000008, close_fds=True)
        if self._mode == "uninstall" and not (INSTALL_DIR / EXE_NAME).exists():
            pass
        elif self._mode == "uninstall":
            schedule_remove_install_dir()
        try:
            self._window.destroy()
        except Exception:
            pass


def run_webview(mode: str) -> None:
    import webview

    api = _Api(mode)
    html = bundle("ui.html").read_text(encoding="utf-8")
    api._window = webview.create_window(
        _tr("Arena Desktop Setup", "Arena Desktop 安装程序") if mode == "install" else _tr("Uninstall Arena Desktop", "卸载 Arena Desktop"), html=html, js_api=api,
        width=440, height=680 if mode == "install" else 660, resizable=False, frameless=True, easy_drag=True,
        background_color="#121514")
    hook = os.environ.get("ARENA_SETUP_AUTOCLICK")  # automated screenshots only
    if hook:
        def autoclick() -> None:
            time.sleep(float(hook) / 1000)
            api._js("document.getElementById('go').click()")
        webview.start(autoclick)
    else:
        webview.start()


def run_gui() -> None:
    try:
        run_webview("install")
    except Exception:
        run_gui_tk()


def run_uninstall_gui() -> None:
    try:
        run_webview("uninstall")
    except Exception:
        run_uninstall_gui_tk()


def main() -> int:
    args = {a.lower() for a in sys.argv[1:]}
    silent = bool(args & {"/s", "-s", "--silent", "/silent"})
    if args & {"/uninstall", "--uninstall"} or Path(sys.executable).stem.lower().startswith("uninstall"):
        if silent:
            uninstall(purge=bool(args & {"/purge", "--purge"}))
        else:
            run_uninstall_gui()
        return 0
    if silent:
        target = install(True)
        if not args & {"/nolaunch", "--nolaunch"}:
            subprocess.Popen([str(target)], cwd=str(target.parent), creationflags=0x00000008, close_fds=True)
        return 0
    run_gui()
    return 0


if __name__ == "__main__":
    sys.exit(main())
