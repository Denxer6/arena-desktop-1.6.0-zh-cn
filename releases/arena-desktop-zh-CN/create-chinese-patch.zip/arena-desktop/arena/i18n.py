"""Small system-locale helper for native desktop surfaces."""

from __future__ import annotations

import locale
import os


def language() -> str:
    """Return zh-CN for a Chinese system locale, otherwise en-US."""
    if os.name == "nt":
        try:
            import ctypes

            if ctypes.windll.kernel32.GetUserDefaultUILanguage() & 0x3FF == 0x04:
                return "zh-CN"
        except Exception:
            pass

    candidates = []
    try:
        candidates.append(locale.getlocale()[0])
    except Exception:
        pass
    candidates.extend(os.environ.get(key) for key in ("LC_ALL", "LC_MESSAGES", "LANG"))
    if any(str(value or "").lower().startswith("zh") for value in candidates):
        return "zh-CN"
    return "en-US"


def is_chinese() -> bool:
    return language() == "zh-CN"


def tr(english: str, chinese: str) -> str:
    return chinese if is_chinese() else english